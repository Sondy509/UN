<footer style="color: white; margin-top: 10px;">
    <p>© 2025 UNOPS. All rights reserved.</p>
</footer>
