<style>
/* =========================
   MENU PRINCIPAL
========================= */
    /* Cache le sous-menu par defaut */
    
    
    /* =========================
    SOUS-MENU
    ========================= */
    .sous_menu {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        background: white;
        min-width: 180px;
        box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        z-index: 999;
    }

    .top-nav ul li:hover .sous_menu {
        display: block;
    }

    .sous_menu ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: block;
    }

    .sous_menu a {
        color: black;
        padding: 10px 15px;
        white-space: nowrap;
    }

    /* Met le li parent comme reference */
    .top-nav ul li {
        position: relative;
    }

    .sous_menu ul li a {
        display: block;
        padding: 10px 15px;
        color: black;
        text-decoration: none;
    }

    .sous_menu ul li a:hover {
        background-color: gray;
        color: white
    }

/* =========================
   MENU HAMBURGER
========================= */
.hamburger {
    display: none;
    flex-direction: column;
    cursor: pointer;
    gap: 5px;
}

.hamburger div {
    width: 25px;
    height: 3px;
    background: white;
    border-radius: 2px;
}

/* =========================
   RESPONSIVE
========================= */
@media (max-width: 768px) {
    .top-nav ul {
        flex-direction: column;
        gap: 0;
        display: none;
        width: 100%;
        background-color: green;
        position: absolute;
        top: 70px;
        left: 0;
        z-index: 1000;
    }

    .top-nav ul.show {
        display: flex;
    }

    .top-nav ul li {
        width: 100%;
    }

    .top-nav ul li a {
        padding: 15px 20px;
    }

    /* Masque sous-menu par défaut */
    .top-nav ul li .sous_menu {
        display: none;
        position: relative;
        top: 0;
        left: 0;
        box-shadow: none;
        background-color: rgba(0,0,0,0.1);
    }

    /* Affichage sous-menu quand actif */
    .top-nav ul li .sous_menu.show {
        display: block;
    }

    .hamburger {
        display: flex;
    }
}
</style>

<header>
    <nav class="top-nav">
        <h1>UNOPS</h1>
        <div class="hamburger">
            <div></div>
            <div></div>
            <div></div>
        </div>
        <ul>
            <li><a href="index.php">Accueil</a></li>
            <li>
                <a href="#">Maison</a>
                <div class="sous_menu">
                    <ul>
                        <li><a href="maisonBasDelmas.php">Bas Delmas</a></li>
                        <li><a href="maisonBasLaVille.php">Bas la Ville</a></li>
                        <li><a href="maisonCiteSoleil.php">Cite-Soleil</a></li>
                        <li><a href="maisonMatissant.php">Matissant</a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="#">Victime</a>
                <div class="sous_menu">
                    <ul>
                        <li><a href="victimeBasDelmas.php">Bas Delmas</a></li>
                        <li><a href="victimeBasLaVille.php">Bas la Ville</a></li>
                        <li><a href="victimeCiteSoleil.php">Cite-Soleil</a></li>
                        <li><a href="victimeMatissant.php">Matissant</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="about.php">A-propos</a></li>
        </ul>
    </nav>
</header>

<script>
// Toggle menu hamburger
const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".top-nav ul");

hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("show");
});

// Toggle sous-menu mobile
const menuItems = document.querySelectorAll(".top-nav ul li");

menuItems.forEach(item => {
    const sousMenu = item.querySelector(".sous_menu");
    if (sousMenu) {
        item.querySelector("a").addEventListener("click", (e) => {
            // seulement sur mobile
            if (window.innerWidth <= 768) {
                e.preventDefault(); // empêche navigation parent
                sousMenu.classList.toggle("show"); // affiche/masque sous-menu
            }
        });
    }
});

// Fermer les sous-menus si on resize > 768px
window.addEventListener("resize", () => {
    if (window.innerWidth > 768) {
        document.querySelectorAll(".sous_menu").forEach(sm => {
            sm.classList.remove("show");
        });
    }
});
</script>
